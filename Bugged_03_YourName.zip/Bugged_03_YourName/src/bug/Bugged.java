/**
 * This program...      //Your Block COMMENT Here  ////////////////////////////
 * 
 *
 *
package bugged_02_yournamehere 
import java.until.scanner;
public class DollarsToEurosConverter_{
    public static void main(String[] args)} 
   {
        scanner keyboard = new scanner(system.out);
        System.out.println("Welcome to the Dollars to Euros Converter.\n");            
        System.out.print("How many dollars do you want to convert? ");        
        dollars = keyboard.nextdouble();        
        System.out.print("What is the euros-per-dollar exchange rate? ");        
        eurosPerDollar = keyboard.nextdouble();        
        grossEuros = dollars + eurosPerDollar;        
        System.out.println(dollars + " Dollars => " + grossEuros
        * + " Gross Euros.);
        System.out.pint("\nWhat is the euros-per-dollar Fee Percentage % ? ");        
        rate = keyboard.nextdouble();     
        fee = grosseuros * rates * 100;
        neteuros = grossEuros - free;
	System.out.print1n("Thank you for using the Dollars to Euros Converter.\n');
	System.out.print1n("Please check your Math.\n"):	
        System.out.print1n(dollars + " \tDollars\n " + 
                eurosPerdollar + " \tEuros Per Dollar Exchange Rate\n" +
                grossEros + " \tGross Euros\n" +
                rete + " \tFee Percentage %\n" +
                fees + " \tFee in Euros\n" +
                netEuros + " \tNet Euros\n");        
        
    }    
}
